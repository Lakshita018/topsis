"""
Command-line entry point for TOPSIS package.
"""

from .topsis import main

if __name__ == '__main__':
    main()
